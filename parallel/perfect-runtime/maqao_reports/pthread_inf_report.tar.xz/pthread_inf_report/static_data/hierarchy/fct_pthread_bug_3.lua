__fct = {
  loops = {
    _0 = {
      src = "pthread_bug.c:62-63",
      src_regions = {
        {
          path = "/home/lenny/maqao/PPN-Validation-of-OQAM-metrics/parallel/perfect-runtime/pthread_bug.c",
          regions = {
            {62, 63},
          },
        },
      },
    },
  },
}
