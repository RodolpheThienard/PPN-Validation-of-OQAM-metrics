_cqa_text_report = {
  paths = {
    {
      hint = {
        {
          details = "Calling (and then returning from) a function prevents many compiler optimizations (like vectorization), breaks control flow (which reduces pipeline performance) and executes extra instructions to save/restore the registers used inside it, which is very expensive (dozens of cycles). Consider to inline small functions.\n - clock_gettime@plt: 2 occurrences\n",
          title = "CALL instructions",
          txt = "Detected function call instructions.\n",
        },
        {
          details = "These instructions generate more than one micro-operation and only one of them can be decoded during a cycle and the extra micro-operations increase pressure on execution units.\n - JMP: 1 occurrences\n - LEAVE: 1 occurrences\n",
          title = "Complex instructions",
          txt = "Detected COMPLEX INSTRUCTIONS.\n",
        },
        {
          title = "Type of elements and instruction set",
          txt = "No instructions are processing arithmetic or math operations on FP elements. This function is probably writing/copying data or processing integer elements.",
        },
        {
          title = "Matching between your function (in the source code) and the binary function",
          txt = "The binary function does not contain any FP arithmetical operations.\nThe binary function is loading 84 bytes.\nThe binary function is storing 56 bytes.",
        },
      },
      expert = {
        {
          title = "General properties",
          txt = "nb instructions    : 32\nnb uops            : 48\nloop length        : 123\nused x86 registers : 6\nused mmx registers : 0\nused xmm registers : 0\nused ymm registers : 0\nused zmm registers : 0\nnb stack references: 7\n",
        },
        {
          title = "Front-end",
          txt = "MACRO FUSION NOT POSSIBLE\nFIT IN UOP CACHE\nmicro-operation queue: 8.00 cycles\nfront end            : 8.00 cycles\n",
        },
        {
          title = "Back-end",
          txt = "       | ALU0 | ALU1 | ALU2 | ALU3 | AGU0 | AGU1 | AGU2 | FP0  | FP1  | FP2  | FP3\n-----------------------------------------------------------------------------------\nuops   | 4.00 | 4.00 | 4.00 | 4.00 | 7.17 | 6.83 | 7.00 | 0.00 | 0.00 | 0.00 | 0.00\ncycles | 4.00 | 4.00 | 4.00 | 4.00 | 7.17 | 6.83 | 7.00 | 0.00 | 0.00 | 0.00 | 0.00\n\nCycles executing div or sqrt instructions: NA\nCycles loading/storing data              : 8.00\n",
        },
        {
          title = "Cycles summary",
          txt = "Front-end : 8.00\nDispatch  : 7.17\nOverall L1: 8.00\n",
        },
        {
          title = "Vectorization ratios",
          txt = "all     : 0%\nload    : 0%\nstore   : 0%\nmul     : NA (no mul vectorizable/vectorized instructions)\nadd-sub : NA (no add-sub vectorizable/vectorized instructions)\nfma     : NA (no fma vectorizable/vectorized instructions)\ndiv/sqrt: NA (no div/sqrt vectorizable/vectorized instructions)\nother   : 0%\n",
        },
        {
          title = "Vector efficiency ratios",
          txt = "all     : 19%\nload    : 12%\nstore   : 20%\nmul     : NA (no mul vectorizable/vectorized instructions)\nadd-sub : NA (no add-sub vectorizable/vectorized instructions)\nfma     : NA (no fma vectorizable/vectorized instructions)\ndiv/sqrt: NA (no div/sqrt vectorizable/vectorized instructions)\nother   : 18%\n",
        },
        {
          title = "Cycles and memory resources usage",
          txt = "Assuming all data fit into the L1 cache, each call to the function takes 8.00 cycles. At this rate:\n - 16% of peak load performance is reached (10.50 out of 64.00 bytes loaded per cycle (GB/s @ 1GHz))\n - 21% of peak store performance is reached (7.00 out of 32.00 bytes stored per cycle (GB/s @ 1GHz))\n",
        },
        {
          title = "Front-end bottlenecks",
          txt = "Performance is limited by instruction throughput (loading/decoding program instructions to execution core) (front-end is a bottleneck).\n\nBy removing all these bottlenecks, you can lower the cost of an iteration from 8.00 to 7.17 cycles (1.12x speedup).\n",
        },
        {
          title = "ASM code",
          txt = "In the binary file, the address of the function is: 11da\n\nInstruction                   | Nb FU | ALU0 | ALU1 | ALU2 | ALU3 | AGU0 | AGU1 | AGU2 | FP0 | FP1 | FP2 | FP3 | Latency | Recip. throughput\n--------------------------------------------------------------------------------------------------------------------------------------------\nPUSH %RBP                     | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 1\nMOV %RSP,%RBP                 | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 0.25\nSUB $0x40,%RSP                | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nMOV %RDI,-0x38(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x38(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x20(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV 0x8(%RAX),%RAX            | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x18(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV 0x10(%RAX),%RAX           | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x10(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV (%RAX),%RAX               | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x8(%RBP)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOVL $0,-0x2c(%RBP)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x18(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,%RSI                 | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 0.25\nMOV $0x4,%EDI                 | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nCALL 1030 <clock_gettime@plt> | 6     | 1.25 | 1.25 | 1.25 | 1.25 | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 0       | 1\nMOVQ $0,-0x28(%RBP)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nJMP 125c <worker+0x82>        | 6     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 2\nMOV -0x10(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,%RSI                 | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 0.25\nMOV $0x4,%EDI                 | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nCALL 1030 <clock_gettime@plt> | 6     | 1.25 | 1.25 | 1.25 | 1.25 | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 0       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV -0x2c(%RBP),%EDX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %EDX,0x18(%RAX)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV $0,%EAX                   | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nLEAVE                         | 2     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.50\nRET                           | 1     | 0.50 | 0    | 0    | 0.50 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.50\n",
        },
      },
      header = {
        "Warnings:\nDetected a function call instruction: ignoring called function instructions.\nRerun with --follow-calls=append to include them to analysis  or with --follow-calls=inline to simulate inlining.",
        "0% of peak computational performance is used (0.00 out of 48.00 FLOP per cycle (GFLOPS @ 1GHz))",
      },
      brief = {
      },
      gain = {
        {
          workaround = " - Try another compiler or update/tune your current one\n - Make array accesses unit-stride:\n  * If your function streams arrays of structures (AoS), try to use structures of arrays instead (SoA)\n",
          details = "All SSE/AVX instructions are used in scalar version (process only one data element in vector registers).\nSince your execution units are vector units, only a vectorized function can use their full power.\n",
          title = "Vectorization",
          txt = "Your function is not vectorized.\nOnly 19% of vector register length is used (average across all SSE/AVX instructions).\nBy vectorizing your function, you can lower the cost of an iteration from 8.00 to 1.16 cycles (6.92x speedup).",
        },
        {
          title = "Execution units bottlenecks",
          txt = "Found no such bottlenecks but see expert reports for more complex bottlenecks.",
        },
      },
      potential = {
      },
    },
  },
  AVG = {
      hint = {
        {
          details = "Calling (and then returning from) a function prevents many compiler optimizations (like vectorization), breaks control flow (which reduces pipeline performance) and executes extra instructions to save/restore the registers used inside it, which is very expensive (dozens of cycles). Consider to inline small functions.\n - clock_gettime@plt: 2 occurrences\n",
          title = "CALL instructions",
          txt = "Detected function call instructions.\n",
        },
        {
          details = "These instructions generate more than one micro-operation and only one of them can be decoded during a cycle and the extra micro-operations increase pressure on execution units.\n - JMP: 1 occurrences\n - LEAVE: 1 occurrences\n",
          title = "Complex instructions",
          txt = "Detected COMPLEX INSTRUCTIONS.\n",
        },
        {
          title = "Type of elements and instruction set",
          txt = "No instructions are processing arithmetic or math operations on FP elements. This function is probably writing/copying data or processing integer elements.",
        },
        {
          title = "Matching between your function (in the source code) and the binary function",
          txt = "The binary function does not contain any FP arithmetical operations.\nThe binary function is loading 84 bytes.\nThe binary function is storing 56 bytes.",
        },
      },
      expert = {
        {
          title = "General properties",
          txt = "nb instructions    : 32\nnb uops            : 48\nloop length        : 123\nused x86 registers : 6\nused mmx registers : 0\nused xmm registers : 0\nused ymm registers : 0\nused zmm registers : 0\nnb stack references: 7\n",
        },
        {
          title = "Front-end",
          txt = "MACRO FUSION NOT POSSIBLE\nFIT IN UOP CACHE\nmicro-operation queue: 8.00 cycles\nfront end            : 8.00 cycles\n",
        },
        {
          title = "Back-end",
          txt = "       | ALU0 | ALU1 | ALU2 | ALU3 | AGU0 | AGU1 | AGU2 | FP0  | FP1  | FP2  | FP3\n-----------------------------------------------------------------------------------\nuops   | 4.00 | 4.00 | 4.00 | 4.00 | 7.17 | 6.83 | 7.00 | 0.00 | 0.00 | 0.00 | 0.00\ncycles | 4.00 | 4.00 | 4.00 | 4.00 | 7.17 | 6.83 | 7.00 | 0.00 | 0.00 | 0.00 | 0.00\n\nCycles executing div or sqrt instructions: NA\nCycles loading/storing data              : 8.00\n",
        },
        {
          title = "Cycles summary",
          txt = "Front-end : 8.00\nDispatch  : 7.17\nOverall L1: 8.00\n",
        },
        {
          title = "Vectorization ratios",
          txt = "all     : 0%\nload    : 0%\nstore   : 0%\nmul     : NA (no mul vectorizable/vectorized instructions)\nadd-sub : NA (no add-sub vectorizable/vectorized instructions)\nfma     : NA (no fma vectorizable/vectorized instructions)\ndiv/sqrt: NA (no div/sqrt vectorizable/vectorized instructions)\nother   : 0%\n",
        },
        {
          title = "Vector efficiency ratios",
          txt = "all     : 19%\nload    : 12%\nstore   : 20%\nmul     : NA (no mul vectorizable/vectorized instructions)\nadd-sub : NA (no add-sub vectorizable/vectorized instructions)\nfma     : NA (no fma vectorizable/vectorized instructions)\ndiv/sqrt: NA (no div/sqrt vectorizable/vectorized instructions)\nother   : 18%\n",
        },
        {
          title = "Cycles and memory resources usage",
          txt = "Assuming all data fit into the L1 cache, each call to the function takes 8.00 cycles. At this rate:\n - 16% of peak load performance is reached (10.50 out of 64.00 bytes loaded per cycle (GB/s @ 1GHz))\n - 21% of peak store performance is reached (7.00 out of 32.00 bytes stored per cycle (GB/s @ 1GHz))\n",
        },
        {
          title = "Front-end bottlenecks",
          txt = "Performance is limited by instruction throughput (loading/decoding program instructions to execution core) (front-end is a bottleneck).\n\nBy removing all these bottlenecks, you can lower the cost of an iteration from 8.00 to 7.17 cycles (1.12x speedup).\n",
        },
        {
          title = "ASM code",
          txt = "In the binary file, the address of the function is: 11da\n\nInstruction                   | Nb FU | ALU0 | ALU1 | ALU2 | ALU3 | AGU0 | AGU1 | AGU2 | FP0 | FP1 | FP2 | FP3 | Latency | Recip. throughput\n--------------------------------------------------------------------------------------------------------------------------------------------\nPUSH %RBP                     | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 1\nMOV %RSP,%RBP                 | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 0.25\nSUB $0x40,%RSP                | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nMOV %RDI,-0x38(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x38(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x20(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV 0x8(%RAX),%RAX            | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x18(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV 0x10(%RAX),%RAX           | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x10(%RBP)          | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV (%RAX),%RAX               | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,-0x8(%RBP)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOVL $0,-0x2c(%RBP)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV -0x18(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,%RSI                 | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 0.25\nMOV $0x4,%EDI                 | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nCALL 1030 <clock_gettime@plt> | 6     | 1.25 | 1.25 | 1.25 | 1.25 | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 0       | 1\nMOVQ $0,-0x28(%RBP)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nJMP 125c <worker+0x82>        | 6     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 2\nMOV -0x10(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %RAX,%RSI                 | 1     | 0    | 0    | 0    | 0    | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 0       | 0.25\nMOV $0x4,%EDI                 | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nCALL 1030 <clock_gettime@plt> | 6     | 1.25 | 1.25 | 1.25 | 1.25 | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 0       | 1\nMOV -0x20(%RBP),%RAX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV -0x2c(%RBP),%EDX          | 1     | 0    | 0    | 0    | 0    | 0.50 | 0.50 | 0    | 0   | 0   | 0   | 0   | 3       | 0.50\nMOV %EDX,0x18(%RAX)           | 1     | 0    | 0    | 0    | 0    | 0.33 | 0.33 | 0.33 | 0   | 0   | 0   | 0   | 4       | 1\nMOV $0,%EAX                   | 1     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.25\nLEAVE                         | 2     | 0.25 | 0.25 | 0.25 | 0.25 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.50\nRET                           | 1     | 0.50 | 0    | 0    | 0.50 | 0    | 0    | 0    | 0   | 0   | 0   | 0   | 1       | 0.50\n",
        },
      },
      header = {
        "Warnings:\nDetected a function call instruction: ignoring called function instructions.\nRerun with --follow-calls=append to include them to analysis  or with --follow-calls=inline to simulate inlining.",
        "0% of peak computational performance is used (0.00 out of 48.00 FLOP per cycle (GFLOPS @ 1GHz))",
      },
      brief = {
      },
      gain = {
        {
          workaround = " - Try another compiler or update/tune your current one\n - Make array accesses unit-stride:\n  * If your function streams arrays of structures (AoS), try to use structures of arrays instead (SoA)\n",
          details = "All SSE/AVX instructions are used in scalar version (process only one data element in vector registers).\nSince your execution units are vector units, only a vectorized function can use their full power.\n",
          title = "Vectorization",
          txt = "Your function is not vectorized.\nOnly 19% of vector register length is used (average across all SSE/AVX instructions).\nBy vectorizing your function, you can lower the cost of an iteration from 8.00 to 1.16 cycles (6.92x speedup).",
        },
        {
          title = "Execution units bottlenecks",
          txt = "Found no such bottlenecks but see expert reports for more complex bottlenecks.",
        },
      },
      potential = {
      },
    },
  common = {
    header = {
      "The function is defined in /home/lenny/maqao/PPN-Validation-of-OQAM-metrics/parallel/perfect-runtime/pthread.c:54-69.\n",
      "Warnings:\nIgnoring paths for analysis",
    },
  },
}
