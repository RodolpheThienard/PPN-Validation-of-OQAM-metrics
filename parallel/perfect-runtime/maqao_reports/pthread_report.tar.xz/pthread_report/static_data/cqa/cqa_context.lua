_cqa_uarch_const = {
  ["RS_ALU2 size"] = 16,
  ["store latency"] = 3,
  ["RS_ALU3 size"] = 16,
  ["ports"] = {
    [1] = {
      ["name"] = "ALU/JMP",
      ["units"] = {
        ["ALU"] = {
        },
      },
    },
    [2] = {
      ["name"] = "ALU",
      ["units"] = {
        ["ALU"] = {
        },
      },
    },
    [3] = {
      ["name"] = "ALU",
      ["units"] = {
        ["ALU"] = {
        },
      },
    },
    [4] = {
      ["name"] = "ALU/JMP",
      ["units"] = {
        ["ALU"] = {
        },
      },
    },
    [5] = {
      ["width"] = 256,
      ["name"] = "LD/STA",
      ["units"] = {
        ["store address"] = {
        },
        ["load"] = {
        },
      },
    },
    [6] = {
      ["width"] = 256,
      ["name"] = "LD/STA",
      ["units"] = {
        ["store address"] = {
        },
        ["load"] = {
        },
      },
    },
    [7] = {
      ["name"] = "STA",
      ["units"] = {
        ["store address"] = {
        },
      },
    },
    [8] = {
      ["width"] = 256,
      ["name"] = "VPU/FMA",
      ["units"] = {
        ["VPU"] = {
        },
      },
    },
    [9] = {
      ["width"] = 256,
      ["name"] = "VPU/FMA",
      ["units"] = {
        ["VPU"] = {
        },
      },
    },
    [10] = {
      ["width"] = 256,
      ["name"] = "VPU/FADD",
      ["units"] = {
        ["VPU"] = {
        },
        ["FP store data"] = {
        },
      },
    },
    [11] = {
      ["width"] = 256,
      ["name"] = "VPU/FADD",
      ["units"] = {
        ["VPU"] = {
        },
        ["DIV/SQRT"] = {
        },
      },
    },
  },
  ["UQ throughput"] = 6,
  ["vector-unaligned optimal pattern"] = "1x256",
  ["RS_ALU1 size"] = 16,
  ["PRF_INT size"] = 180,
  ["UFS resources"] = {
    [1] = "ROB",
    [2] = "RS_ALU0",
    [3] = "RS_ALU1",
    [4] = "RS_ALU2",
    [5] = "RS_ALU3",
    [6] = "RS_VPU",
    [7] = "RS_MEM",
    [8] = "LB",
    [9] = "LFB",
    [10] = "SB",
    [11] = "PRF_INT",
    [12] = "PRF_FLOAT",
  },
  ["NOP 0f 1f decode"] = "fast",
  ["load latency"] = 4,
  ["FP load latency"] = 7,
  ["RS_MEM size"] = 92,
  ["LFB size"] = 22,
  ["uop cache capacity"] = 2600,
  ["RS_VPU size"] = 36,
  ["PRF_FLOAT size"] = 160,
  ["vector size in bytes"] = 32,
  ["RS_ALU0 size"] = 16,
  ["LB size"] = 44,
  ["predicted taken branch ports"] = {
    [1] = 0,
  },
  ["SB size"] = 48,
  ["nb execution ports"] = 11,
  ["IQ throughput"] = 4,
  ["ROB size"] = 224,
  ["INT vector size in bytes"] = 32,
  ["bytes fetched per cycle"] = 32,
  ["retire throughput"] = 8,
  ["aliases"] = {
    ["RS_ALU0"] = "ALQ0",
    ["RS_ALU2"] = "ALQ2",
    ["RS_VPU"] = "SQ",
    ["RS_ALU1"] = "ALQ1",
    ["LFB"] = "MAB",
    ["SB"] = "STQ",
    ["RS_ALU3"] = "ALQ3",
    ["ROB"] = "RQ",
    ["RS_MEM"] = "AGQ",
    ["LB"] = "LDQ",
  },
}
